# Import required libraries
import pygame  # Main game library
import random  # For randomization
import time    # For timing functions

# Import pygame modules
import pygame
import pygame.mixer

# Initialize audio
pygame.mixer.init()  # Initialize the mixer module first

# Initialize Pygame and start background music
pygame.init()
pygame.mixer.music.load('bg.mp3')  # Load background music file
pygame.mixer.music.play(-1)  # Play music on loop (-1 means infinite loop)

# Set up the game window dimensions
WINDOW_WIDTH = 1200
WINDOW_HEIGHT = 800
screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))  # Create game window
pygame.display.set_caption("Cyber Security Farming Game")  # Set window title

# Define colors using RGB values
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
BROWN = (139, 69, 19)
SOFT_GREEN = (144, 238, 144)  # Light green background color
RED = (255, 0, 0)

# Load and scale background image to fit window
background = pygame.image.load('background.jpg')
background = pygame.transform.scale(background, (WINDOW_WIDTH, WINDOW_HEIGHT))

# Draw background on screen
screen.blit(background, (0, 0))

# Create and display initial instruction text
font = pygame.font.Font(None, 36)  # Set up font for text
instruction_text = "You must click once to water, click once to trim the plant then click again to complete the growth!"
text_surface = font.render(instruction_text, True, BLACK)  # Create text surface
text_rect = text_surface.get_rect(center=(WINDOW_WIDTH/2, WINDOW_HEIGHT/2))  # Center text
screen.blit(text_surface, text_rect)  # Draw text on screen
instruction_start_time = time.time()  # Track when instructions started
show_instruction = True  # Flag to control instruction visibility

# Player class to handle character movement and animation
class Player:
    def __init__(self):
        # Initialize player position and attributes
        self.x = 400
        self.y = 300
        self.speed = 0.5  # Movement speed
        self.width = 80  
        self.height = 80
        self.plants_planted = 0  # Track planted plants
        self.has_defeated_enemy = False  # Track if final boss is defeated
        
        # Load character animation sprites for each direction
        self.sprites = {
            'down': [pygame.image.load(f'character/down/{i}.png') for i in range(1, 4)],
            'up': [pygame.image.load(f'character/up/{i}.png') for i in range(1, 4)],
            'left': [pygame.image.load(f'character/left/{i}.png') for i in range(1, 4)],
            'right': [pygame.image.load(f'character/right/{i}.png') for i in range(1, 4)],
            'idle': pygame.image.load('character/down/1.png')
        }
        # Scale all sprites to match player size
        for direction in self.sprites:
            if direction != 'idle':
                self.sprites[direction] = [pygame.transform.scale(img, (self.width, self.height)) 
                                         for img in self.sprites[direction]]
            else:
                self.sprites[direction] = pygame.transform.scale(self.sprites[direction], 
                                                              (self.width, self.height))
        
        # Animation control variables
        self.current_direction = 'idle'
        self.animation_index = 0
        self.animation_timer = 0
        self.animation_delay = 100  # milliseconds between frames

    def move(self):
        # Handle keyboard input for movement
        keys = pygame.key.get_pressed()
        moving = False
        
        # Check arrow key presses and update position
        if keys[pygame.K_LEFT]:
            self.x -= self.speed
            self.current_direction = 'left'
            moving = True
        if keys[pygame.K_RIGHT]:
            self.x += self.speed
            self.current_direction = 'right'
            moving = True
        if keys[pygame.K_UP]:
            self.y -= self.speed
            self.current_direction = 'up'
            moving = True
        if keys[pygame.K_DOWN]:
            self.y += self.speed
            self.current_direction = 'down'
            moving = True
            
        # Reset to idle if not moving
        if not moving:
            self.current_direction = 'idle'
            self.animation_index = 0
        
        # Keep player within screen bounds
        self.x = max(0, min(self.x, WINDOW_WIDTH - self.width))
        self.y = max(0, min(self.y, WINDOW_HEIGHT - self.height))
        
        # Update animation frame
        current_time = pygame.time.get_ticks()
        if current_time - self.animation_timer > self.animation_delay and moving:
            self.animation_timer = current_time
            self.animation_index = (self.animation_index + 1) % 3

    def draw(self):
        # Draw player sprite based on current direction and animation frame
        if self.current_direction == 'idle':
            screen.blit(self.sprites['idle'], (self.x, self.y))
        else:
            current_sprite = self.sprites[self.current_direction][self.animation_index % 3]
            screen.blit(current_sprite, (self.x, self.y))

# Plant spot class to handle planting locations
class PlantSpot:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.width = 60
        self.height = 60
        self.planted = False  # Track if plant is fully grown
        self.rect = pygame.Rect(x, y, self.width, self.height)  # Collision detection
        self.questions_answered = 0  # Track quiz progress
        self.required_questions = 3  # Questions needed to grow plant
        # Load plant growth stage images
        self.plant_image = pygame.transform.scale(pygame.image.load('fruit/corn/1.png'), (self.width, self.height))
        self.grown_image = pygame.transform.scale(pygame.image.load('fruit/corn/3.png'), (self.width, self.height))

    def draw(self):
        # Draw appropriate plant image based on growth state
        if self.planted:
            screen.blit(self.grown_image, (self.x, self.y))
        else:
            screen.blit(self.plant_image, (self.x, self.y))

# Enemy class for final boss
class Enemy:
    def __init__(self):
        self.width = 200
        self.height = 200
        # Center enemy on screen
        self.x = WINDOW_WIDTH//2 - self.width//2
        self.y = WINDOW_HEIGHT//2 - self.height//2
        self.rect = pygame.Rect(self.x, self.y, self.width, self.height)
        self.questions_answered = 0  # Track quiz progress
        self.required_questions = 5  # Questions needed to defeat
        self.image = pygame.transform.scale(pygame.image.load('hacker.jpg'), (self.width, self.height))
        
    def draw(self):
        # Draw enemy sprite and text above it
        warning_text = font.render("A cyber threat has appeared! Answer security questions to defeat it!", True, RED)
        warning_rect = warning_text.get_rect(center=(self.x + self.width//2, self.y - 30))
        screen.blit(warning_text, warning_rect)
        screen.blit(self.image, (self.x, self.y))

# Quiz questions database organized by category
questions = {
    0: [ # Phishing questions
        {
            "question": "Which is a common sign of a phishing email?",
            "options": ["Urgent action required", "From a known colleague", "Company logo present", "Clear subject line"],
            "correct": 0
        },
        {
            "question": "What should you do if you receive a suspicious email?",
            "options": ["Open attachments", "Click links to check", "Delete immediately", "Report and delete"],
            "correct": 3
        },
        {
            "question": "Which email sender is most likely phishing?",
            "options": ["support@company.com", "suPporT@company.net", "hr@company.com", "help@company.com"],
            "correct": 1
        }
    ],
    1: [ # Scamming questions
        {
            "question": "What is a common online scam tactic?",
            "options": ["Free virus scan", "Software updates", "Customer support", "Account verification"],
            "correct": 0
        },
        {
            "question": "Which is something that you should not use to transfer money to suspicious people?",
            "options": ["Wire transfer", "Credit card", "Gift cards", "All of the above"],
            "correct": 3
        },
        {
            "question": "What's a red flag for online shopping scams?",
            "options": ["Prices too good to be true", "Secure payment options", "Professional website", "Customer reviews"],
            "correct": 0
        }
    ],
    2: [ # Malware questions
        {
            "question": "How can malware infect your computer?",
            "options": ["Downloading attachments", "Using antivirus", "Regular updates", "Strong passwords"],
            "correct": 0
        },
        {
            "question": "Which is a sign of malware infection?",
            "options": ["Slow performance", "Regular updates", "Normal startup", "Clear display"],
            "correct": 0
        },
        {
            "question": "What helps prevent malware infection?",
            "options": ["Opening all emails", "Installing unknown software", "Using antivirus", "Disabling firewall"],
            "correct": 2
        }
    ],
    3: [ # Final boss questions
        {
            "question": "What is two-factor authentication?",
            "options": ["Using two passwords", "A second verification step", "Two different emails", "Double encryption"],
            "correct": 1
        },
        {
            "question": "Which password is strongest?",
            "options": ["Password123", "MyBirthday1990", "K9$mP#2@vL5", "qwerty12345"],
            "correct": 2
        },
        {
            "question": "How often should you update your passwords?",
            "options": ["Never", "Every few years", "Every 3-6 months", "Only when hacked"],
            "correct": 2
        },
        {
            "question": "What is a secure way to store passwords?",
            "options": ["Text file", "Password manager", "Browser save", "Sticky note"],
            "correct": 1
        },
        {
            "question": "What should you do before clicking a link?",
            "options": ["Click immediately", "Hover to preview URL", "Open in new tab", "Copy and paste"],
            "correct": 1
        }
    ]
}

def show_quiz(spot_or_enemy):
    # Check if all questions are already answered
    if isinstance(spot_or_enemy, PlantSpot):
        if spot_or_enemy.questions_answered >= spot_or_enemy.required_questions:
            return True
        plant_type = plant_spots.index(spot_or_enemy)
        plant_questions = questions[plant_type]
        available_questions = plant_questions[spot_or_enemy.questions_answered:spot_or_enemy.required_questions]
    else:  # Enemy quiz
        if spot_or_enemy.questions_answered >= spot_or_enemy.required_questions:
            return True
        available_questions = questions[3][spot_or_enemy.questions_answered:spot_or_enemy.required_questions]
    
    if not available_questions:
        return False
        
    # Get current question and setup quiz display
    current_question = available_questions[0]
    font = pygame.font.Font(None, 36)
    
    while True:
        screen.fill(WHITE)
        y_pos = 100
        
        # Draw question counter
        counter_text = font.render(f"Question {spot_or_enemy.questions_answered + 1} of {spot_or_enemy.required_questions}", True, BLACK)
        screen.blit(counter_text, (50, 50))
        
        # Draw question text
        question_text = font.render(current_question["question"], True, BLACK)
        screen.blit(question_text, (50, y_pos))
        
        # Draw answer options
        for i, option in enumerate(current_question["options"]):
            y_pos += 50
            option_text = font.render(f"{i+1}. {option}", True, BLACK)
            screen.blit(option_text, (50, y_pos))
        
        pygame.display.flip()
        
        # Handle answer input
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key in [pygame.K_1, pygame.K_2, pygame.K_3, pygame.K_4]:
                    answer = event.key - pygame.K_1
                    correct = answer == current_question["correct"]
                    
                    # Show feedback based on answer
                    if correct:
                        feedback = font.render("✓ Correct! Well done!", True, GREEN)
                        screen.blit(feedback, (WINDOW_WIDTH//2 - 100, WINDOW_HEIGHT//2))
                        # Draw green circle around correct answer
                        y_pos = 150 + (current_question["correct"] + 1) * 50
                        pygame.draw.circle(screen, GREEN, (35, y_pos), 15, 2)
                    else:
                        feedback = font.render("✗ Incorrect! Try again!", True, RED)
                        screen.blit(feedback, (WINDOW_WIDTH//2 - 100, WINDOW_HEIGHT//2))
                        # Show correct answer
                        correct_ans = font.render(f"The correct answer was: {current_question['options'][current_question['correct']]}", True, BLACK)
                        screen.blit(correct_ans, (50, WINDOW_HEIGHT//2 + 50))
                    
                    pygame.display.flip()
                    pygame.time.wait(2000)  # Show feedback for 2 seconds
                    
                    if correct:
                        spot_or_enemy.questions_answered += 1
                    return correct

# Create game objects
player = Player()
# Create plant spots evenly spaced across top of screen
plant_spots = [
    PlantSpot(200, 100),
    PlantSpot(550, 100),
    PlantSpot(900, 100)
]
enemy = Enemy()
enemy_spawned = False

# Main game loop
running = True
font = pygame.font.Font(None, 36)

while running:
    # Handle game events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            mouse_pos = pygame.mouse.get_pos()
            # Check plant spot interactions
            for spot in plant_spots:
                if not spot.planted and spot.rect.collidepoint(mouse_pos):
                    if (abs(player.x - spot.x) < 100 and
                        abs(player.y - spot.y) < 100):
                        # Show quiz when clicking plant
                        if show_quiz(spot):
                            if spot.questions_answered >= spot.required_questions:
                                spot.planted = True
                                player.plants_planted += 1
            
            # Check enemy interactions
            if enemy_spawned and not player.has_defeated_enemy and enemy.rect.collidepoint(mouse_pos):
                if (abs(player.x - enemy.x) < 100 and
                    abs(player.y - enemy.y) < 100):
                    if show_quiz(enemy):
                        if enemy.questions_answered >= enemy.required_questions:
                            player.has_defeated_enemy = True
    
    # Handle handbook display when E is pressed
    keys = pygame.key.get_pressed()
    if keys[pygame.K_e]:
        current_page = "main"
        showing_handbook = True
        
        while showing_handbook:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    showing_handbook = False
                    running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_e or event.key == pygame.K_ESCAPE:
                        showing_handbook = False
                    elif event.key == pygame.K_q:
                        showing_handbook = False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    mouse_pos = pygame.mouse.get_pos()
                    # Check handbook navigation button clicks
                    if 220 <= mouse_pos[0] <= 420 and 650 <= mouse_pos[1] <= 680:
                        current_page = "phishing"
                    elif 480 <= mouse_pos[0] <= 680 and 650 <= mouse_pos[1] <= 680:
                        current_page = "scams"
                    elif 740 <= mouse_pos[0] <= 940 and 650 <= mouse_pos[1] <= 680:
                        current_page = "malware"
                    elif 900 <= mouse_pos[0] <= 1000 and 100 <= mouse_pos[1] <= 130:
                        showing_handbook = False
            
            # Draw handbook interface
            handbook_surface = pygame.Surface((800, 500))
            handbook_surface.fill((255, 255, 255))
            screen.blit(handbook_surface, (200, 150))
            
            # Draw exit button
            pygame.draw.rect(screen, (200, 200, 200), (900, 100, 100, 30))
            exit_text = font.render("Exit", True, BLACK)
            screen.blit(exit_text, (925, 105))
            
            # Draw handbook title
            title = font.render("Cyber Security Handbook", True, BLACK)
            screen.blit(title, (450, 170))
            
            # Draw content based on current handbook page
            y_pos = 220
            if current_page == "main":
                topics = [
                    "Welcome to the Cyber Security Handbook!",
                    "",
                    "Here you'll find important information about",
                    "staying safe in the digital world.",
                    "",
                    "Click the buttons below to learn more about:",
                    "- Email Phishing",
                    "- Online Scams",
                    "- Malware Protection",
                    "",
                    "Press 'E', 'ESC', or 'Q' to close the handbook",
                    "Or click the Exit button in the top-right corner"
                ]
            elif current_page == "phishing":
                topics = [
                    "Email Phishing Safety:",
                    "",
                    "Common Signs of Phishing:",
                    "- Urgent action requests",
                    "- Suspicious sender addresses (Coimpany@rad.net.info)",
                    "- Poor grammar or spelling",
                    "- Requests for sensitive information",
                    "",
                    "What to Do:",
                    "- Never open suspicious attachments",
                    "- Report suspicious emails",
                    "- Check sender carefully"
                ]
            elif current_page == "scams":
                topics = [
                    "Online Scam Protection:",
                    "",
                    "Common Scam Tactics:",
                    "- Fake 'free' virus scans",
                    "- Too-good-to-be-true offers",
                    "- Fake tech support calls",
                    "",
                    "Stay Safe:",
                    "- Avoid sending money to suspicious people",
                    "- Verify website security",
                    "- Never send gift cards as payment",
                    "- Don't trust unsolicited calls"
                ]
            elif current_page == "malware":
                topics = [
                    "Malware Protection:",
                    "",
                    "Types of Malware:",
                    "- Viruses: Infect and damage files",
                    "- Ransomware: Encrypts your files",
                    "- Spyware: Steals your information",
                    "- Trojans: Disguised as legitimate software",
                    "",
                    "Prevention Tips:",
                    "- Keep software updated",
                    "- Use antivirus protection",
                    "- Don't download from untrusted sources",
                    "- Back up important files regularly"
                ]
            
            # Draw handbook content
            for line in topics:
                text = font.render(line, True, BLACK)
                screen.blit(text, (220, y_pos))
                y_pos += 30
            
            # Draw navigation buttons
            pygame.draw.rect(screen, (200, 200, 200), (220, 650, 200, 30))
            pygame.draw.rect(screen, (200, 200, 200), (480, 650, 200, 30))
            pygame.draw.rect(screen, (200, 200, 200), (740, 650, 200, 30))
            
            phishing_btn = font.render("Email Phishing", True, BLACK)
            scams_btn = font.render("Online Scams", True, BLACK)
            malware_btn = font.render("Malware", True, BLACK)
            screen.blit(phishing_btn, (240, 655))
            screen.blit(scams_btn, (510, 655))
            screen.blit(malware_btn, (790, 655))
            
            pygame.display.flip()

    # Move player character
    player.move()
    
    # Draw game state
    if player.has_defeated_enemy:
        # Show win screen
        screen.fill(GREEN)
        win_font = pygame.font.Font(None, 72)
        win_text = win_font.render("You Win!", True, BLACK)
        win_rect = win_text.get_rect(center=(WINDOW_WIDTH/2, WINDOW_HEIGHT/2))
        screen.blit(win_text, win_rect)
    else:
        # Draw normal game screen
        screen.blit(background, (0, 0))
        for spot in plant_spots:
            spot.draw()
        player.draw()
    
    # Spawn enemy when all plants are grown
    if player.plants_planted == 3 and not player.has_defeated_enemy:
        enemy_spawned = True
        enemy.draw()
    
    # Draw UI elements
    counter_text = font.render(f"Plants: {player.plants_planted}/3", True, BLACK)
    screen.blit(counter_text, (10, 10))
    
    handbook_text = font.render("Press E to open Farmer's Handbook", True, BLACK)
    screen.blit(handbook_text, (10, WINDOW_HEIGHT - 40))
    
    # Show initial game instructions
    if show_instruction and time.time() - instruction_start_time < 10:
        instruction_text = "You must click once to water, click once to trim the plant,"
        instruction_text2 = "then click again to complete the growth! Go near things to interact!"
        instruction_text3 = "Complete the questions! READ THE HANDBOOK FIRST!"
        instruction_text4 = "Use 1-2-3-4 on your keyboard to answer the questions"
        instruction_text5 = "Go near the plants and click to activiate the quiz! Use arrow keys to move around!"
        
        text_surface = font.render(instruction_text, True, BLACK)
        text_surface2 = font.render(instruction_text2, True, BLACK)
        text_surface3 = font.render(instruction_text3, True, BLACK)
        text_surface4 = font.render(instruction_text4, True, BLACK)
        text_surface5 = font.render(instruction_text5, True, BLACK)
        
        text_rect = text_surface.get_rect(center=(WINDOW_WIDTH/2, WINDOW_HEIGHT/2 - 80))
        text_rect2 = text_surface2.get_rect(center=(WINDOW_WIDTH/2, WINDOW_HEIGHT/2 - 40))
        text_rect3 = text_surface3.get_rect(center=(WINDOW_WIDTH/2, WINDOW_HEIGHT/2))
        text_rect4 = text_surface4.get_rect(center=(WINDOW_WIDTH/2, WINDOW_HEIGHT/2 + 40))
        text_rect5 = text_surface5.get_rect(center=(WINDOW_WIDTH/2, WINDOW_HEIGHT/2 + 80))
        
        screen.blit(text_surface, text_rect)
        screen.blit(text_surface2, text_rect2)
        screen.blit(text_surface3, text_rect3)
        screen.blit(text_surface4, text_rect4)
        screen.blit(text_surface5, text_rect5)
    else:
        show_instruction = False
    
    # Show game state messages
    if player.has_defeated_enemy:
        win_text = font.render("Congratulations! You've defeated the cyber threat!", True, BLACK)
        screen.blit(win_text, (WINDOW_WIDTH//2 - 250, WINDOW_HEIGHT//2 + 50))
    
    # Update display
    pygame.display.flip()

# Quit game when loop ends
pygame.quit()
