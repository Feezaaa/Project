import pygame
import random
import os
from typing import Dict, List, Tuple

class CyberGarden:
    def __init__(self):
        self.plants = {
            'firewall_flower': {
                'name': 'Firewall Flower',
                'planted': False,
                'quiz_completed': False
            },
            'secure_succulent': {
                'name': 'Security Succulent', 
                'planted': False,
                'quiz_completed': False
            },
            'privacy_palm': {
                'name': 'Privacy Palm',
                'planted': False,
                'quiz_completed': False
            }
        }
        
        self.quiz_questions = {
            'firewall_flower': [
                {
                    'question': 'Which is a common sign of a phishing email?',
                    'options': ['Urgent action required', 'From a known colleague', 'Company logo present', 'Clear subject line'],
                    'correct': 0
                },
                {
                    'question': 'What should you do if you receive a suspicious email?',
                    'options': ['Open attachments', 'Click links to check', 'Delete immediately', 'Report and delete'],
                    'correct': 3
                },
                {
                    'question': 'Which email sender is most likely phishing?',
                    'options': ['support@company.com', 'support@company.net.info', 'hr@company.com', 'help@company.com'],
                    'correct': 1
                }
            ],
            'secure_succulent': [
                {
                    'question': 'What is a common online scam tactic?',
                    'options': ['Free virus scan', 'Software updates', 'Customer support', 'Account verification'],
                    'correct': 0
                },
                {
                    'question': 'Which payment method is safest for online purchases?',
                    'options': ['Wire transfer', 'Credit card', 'Gift cards', 'Direct bank transfer'],
                    'correct': 1
                },
                {
                    'question': 'What indicates a potential romance scam?',
                    'options': ['Shares photos', 'Asks for money', 'Lives nearby', 'Has social media'],
                    'correct': 1
                }
            ],
            'privacy_palm': [
                {
                    'question': 'Which is a sign of malware infection?',
                    'options': ['Slow computer', 'Windows updates', 'Antivirus alerts', 'New browser'],
                    'correct': 0
                },
                {
                    'question': 'How does ransomware typically spread?',
                    'options': ['Email attachments', 'Official updates', 'Security patches', 'System scans'],
                    'correct': 0
                },
                {
                    'question': 'What helps prevent malware infection?',
                    'options': ['Disable firewall', 'Skip updates', 'Regular updates', 'Multiple browsers'],
                    'correct': 2
                }
            ]
        }
        
        self.handbook = {
            'firewall_flower': [
                "Phishing emails often create urgency or threats",
                "Check sender addresses carefully for slight misspellings", 
                "Never click links or download attachments from unknown sources"
            ],
            'secure_succulent': [
                "Be wary of deals that seem too good to be true",
                "Use secure payment methods like credit cards for protection",
                "Never send money to someone you haven't met in person"
            ],
            'privacy_palm': [
                "Keep software and systems regularly updated",
                "Be cautious of unexpected email attachments",
                "Install and maintain reputable antivirus software"
            ]
        }
        
        # Player attributes
        self.player_pos = [400, 300]  # Start in middle of screen
        self.player_speed = 5
        self.player_rect = pygame.Rect(self.player_pos[0], self.player_pos[1], 32, 32)
        
    def show_handbook(self, plant: str) -> List[str]:
        return self.handbook.get(plant, [])
        
    def take_quiz(self, plant: str) -> bool:
        if plant not in self.quiz_questions:
            return False
            
        correct_answers = 0
        questions = self.quiz_questions[plant]
        
        for question in questions:
            # In a real implementation, this would display the question and options
            # and handle user input through the game interface
            pass
            
        return correct_answers >= 2  # Need 2 out of 3 correct to pass
        
    def plant_seed(self, plant: str) -> bool:
        if plant not in self.plants:
            return False
            
        if self.plants[plant]['quiz_completed']:
            self.plants[plant]['planted'] = True
            return True
            
        return False
        
    def check_game_complete(self) -> bool:
        return all(plant['planted'] for plant in self.plants.values())
        
    def handle_movement(self, keys):
        if keys[pygame.K_w]:
            self.player_pos[1] -= self.player_speed
        if keys[pygame.K_s]:
            self.player_pos[1] += self.player_speed
        if keys[pygame.K_a]:
            self.player_pos[0] -= self.player_speed
        if keys[pygame.K_d]:
            self.player_pos[0] += self.player_speed
            
        # Update player rectangle position
        self.player_rect.x = self.player_pos[0]
        self.player_rect.y = self.player_pos[1]
        
        # Keep player in bounds
        self.player_rect.clamp_ip(pygame.Rect(0, 0, 800, 600))
        self.player_pos[0] = self.player_rect.x
        self.player_pos[1] = self.player_rect.y
        
    def run_game(self):
        pygame.init()
        
        # Set up display
        WINDOW_WIDTH = 800
        WINDOW_HEIGHT = 600
        
        # Center the window on the desktop
        os.environ['SDL_VIDEO_CENTERED'] = '1'
        
        screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
        pygame.display.set_caption("Cyber Garden")
        
        clock = pygame.time.Clock()
        
        # Game loop
        running = True
        while running:
            # Cap framerate
            clock.tick(60)
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                    
            # Handle player movement
            keys = pygame.key.get_pressed()
            self.handle_movement(keys)
                    
            # Clear screen
            screen.fill((124, 252, 0))  # Green background for garden
            
            # Draw player
            pygame.draw.rect(screen, (255, 0, 0), self.player_rect)  # Red rectangle for player
            
            # Update display
            pygame.display.flip()
            
        pygame.quit()
